<template>
    <div class="ps-card-block">
        <slot/>
    </div>
</template>

<script>
export default {
    name: 'PsCardBlock'
}
</script>

<style scoped lang="scss">
.ps-card-block {
    padding: 20px;
    padding: 1.25rem;
}
</style>
